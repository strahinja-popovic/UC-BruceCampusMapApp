package com.cel.strahinja_popovic.uc_brucecampusmapapp_u3165021;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import static android.graphics.Color.argb;

public class BruceCampusMapsActivity extends AppCompatActivity implements OnMapReadyCallback
{
    private GoogleMap mMap;
    private int clickCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bruce_campus_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.maps);
        mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        mMap = googleMap;
        final PolygonOptions polygonOptions = new PolygonOptions()
                .geodesic(true)
                .clickable(true)
                .add(new LatLng(-35.230939, 149.080460))
                .add(new LatLng(-35.231339, 149.082535))
                .add(new LatLng(-35.232374, 149.085161))
                .add(new LatLng(-35.233645, 149.087405))
                .add(new LatLng(-35.234348, 149.089590))
                .add(new LatLng(-35.234732, 149.092012))
                .add(new LatLng(-35.238515, 149.090576))
                .add(new LatLng(-35.240155, 149.090147))
                .add(new LatLng(-35.242007, 149.090300))
                .add(new LatLng(-35.242304, 149.089078))
                .add(new LatLng(-35.242425, 149.088321))
                .add(new LatLng(-35.242420, 149.086805))
                .add(new LatLng(-35.242350, 149.079806))
                .add(new LatLng(-35.242395, 149.078330))
                .add(new LatLng(-35.242426, 149.077451))
                .add(new LatLng(-35.242056, 149.076400))
                .add(new LatLng(-35.240847, 149.074851))
                .add(new LatLng(-35.237725, 149.077019))
                .add(new LatLng(-35.235505, 149.077646))
                .add(new LatLng(-35.233934, 149.078541))
                .add(new LatLng(-35.232424, 149.079679))
                .add(new LatLng(-35.230939, 149.080460))
                .strokeWidth(30)
                .strokeColor(Color.RED)
                .fillColor(argb(20, 50, 0, 255));

        final Polygon bruce_polygon = mMap.addPolygon(polygonOptions);
        bruce_polygon.setTag("alpha");

        mMap.setOnPolygonClickListener(new GoogleMap.OnPolygonClickListener()
        {
            @Override
            public void onPolygonClick(Polygon polygon)
            {
                clickCount = clickCount + 1;
                if(clickCount == 1)
                {
                    if(polygon.getTag() == "alpha")
                    {
                        bruce_polygon.setStrokeColor(Color.BLACK);
                        Context context = getApplicationContext();
                        String descriptionToast = "University of Canberra (UC-ID: u3165021)";
                        int duration = Toast.LENGTH_LONG;
                        Toast toast = Toast.makeText(context, descriptionToast, duration);
                        toast.show();
                    }
                }
            }
        });

        final LatLng canberra = new LatLng(-35.238132, 149.084083);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(canberra, 15));
        final Marker canberraMarker = mMap.addMarker(new MarkerOptions()
                .position(canberra)
                .title("University of Canberra - Bruce Campus")
                .snippet("Australia's Capital University")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.red_locator)));

        final LatLng hub = new LatLng(-35.237972, 149.083963);
        final Marker hubMarker = mMap.addMarker(new MarkerOptions()
                .position(hub)
                .title("UC Student hub")
                .snippet("University hub space location")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.hub)));

        final LatLng library = new LatLng(-35.238015, 149.083409);
        final Marker libraryMarker = mMap.addMarker(new MarkerOptions()
                .position(library)
                .title("UC Student Library")
                .snippet("University Library for students")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.library_blue)));

        final LatLng gym1 = new LatLng(-35.238408, 149.088302);
        final Marker gym1Marker = mMap.addMarker(new MarkerOptions()
                .position(gym1)
                .title("UC Student Gym")
                .snippet("UC Fit, Sport and Health")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.gym)));

        final LatLng gym2 = new LatLng(-35.238582, 149.087293);
        final Marker gym2Marker = mMap.addMarker(new MarkerOptions()
                .position(gym2)
                .title("UC Sport Gym")
                .snippet("UC Fit, Sport and Health")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.gym)));

        final LatLng parking = new LatLng(-35.241774, 149.084845);
        final Marker parkingMarker = mMap.addMarker(new MarkerOptions()
                .position(parking)
                .title("Parking")
                .snippet("UC Parking facility area")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.parking)));

        final LatLng studentCenter = new LatLng(-35.236421, 149.084013);
        final Marker studentCenterMarker = mMap.addMarker(new MarkerOptions()
                .position(studentCenter)
                .title("UC Student Centre")
                .snippet("Your gateway to access support and advice")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.ask_sc)));

        final LatLng coffee = new LatLng(-35.239094, 149.082214);
        final Marker coffeeMarker = mMap.addMarker(new MarkerOptions()
                .position(coffee)
                .title("Coffee Grounds")
                .snippet("The best coffee on campus")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.caffee)));

        final LatLng natsemCenter = new LatLng(-35.240880, 149.085871);
        final Marker natsemCenterMarker = mMap.addMarker(new MarkerOptions()
                .position(natsemCenter)
                .title("NATSEM Centre")
                .snippet("The National Centre for Social and Economic Modelling")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.center)));

        final LatLng streetView1 = new LatLng(-35.233730, 149.087258);
        final Marker streetView1Marker = mMap.addMarker(new MarkerOptions()
                .position(streetView1)
                .title("Exit North")
                .snippet("Street view")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.exit)));

        final LatLng streetView2 = new LatLng(-35.238492, 149.089579);
        final Marker streetView2Marker = mMap.addMarker(new MarkerOptions()
                .position(streetView2)
                .title("Exit East")
                .snippet("Street view")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.exit)));

        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter()
        {
            @Override
            public View getInfoWindow(Marker marker)
            {
                return null;
            }

            @Override
            public View getInfoContents(Marker marker)
            {
                View infoWindow = getLayoutInflater().inflate(R.layout.canberra_info_marker, null);
                TextView title = (TextView) infoWindow.findViewById(R.id.textViewTitle);
                TextView snippet = (TextView) infoWindow.findViewById(R.id.textViewSnippet);
                ImageView image = (ImageView) infoWindow.findViewById(R.id.imageView);

                if (marker.getId().equals(canberraMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.uc_cube_logo_blue, getTheme()));
                }
                else if (marker.getId().equals(hubMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.hub_desc, getTheme()));
                }
                else if (marker.getId().equals(libraryMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.library_description, getTheme()));
                }
                else if (marker.getId().equals(gym1Marker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.gym_desc, getTheme()));
                }
                else if (marker.getId().equals(gym2Marker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.gym_desc, getTheme()));
                }
                else if (marker.getId().equals(parkingMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.parking_desc, getTheme()));
                }
                else if (marker.getId().equals(studentCenterMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.ask_sc_desc, getTheme()));
                }
                else if (marker.getId().equals(coffeeMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.caffee_desc, getTheme()));
                }
                else if (marker.getId().equals(natsemCenterMarker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.center_desc, getTheme()));
                }
                else if (marker.getId().equals(streetView1Marker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.exit_desc, getTheme()));
                    Intent intent = new Intent(BruceCampusMapsActivity.this, StreetViewNorthActivity.class);
                    startActivity(intent);
                }
                else if (marker.getId().equals(streetView2Marker.getId()))
                {
                    title.setText(marker.getTitle());
                    snippet.setText(marker.getSnippet());
                    image.setImageDrawable(getResources().getDrawable(R.drawable.exit_desc, getTheme()));
                    Intent intent = new Intent(BruceCampusMapsActivity.this, StreetViewEastActivity.class);
                    startActivity(intent);
                }
                return infoWindow;
            }
        });
        mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener()
        {
            @Override
            public void onInfoWindowClick(Marker marker)
            {
                if(marker.getId().equals(hubMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, HubWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(libraryMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, LibraryWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(gym1Marker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, GymWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(gym2Marker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, GymWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(parkingMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, ParkingWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(studentCenterMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, StudentCenterWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(coffeeMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, CoffeeGroundsWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(natsemCenterMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, NatsemCenterWebViewActivity.class);
                    startActivity(intent);
                }
                else if(marker.getId().equals(canberraMarker.getId()))
                {
                    Intent intent = new Intent(BruceCampusMapsActivity.this, UniversityOfCanberraWebViewActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_map, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == R.id.normalView)
        {
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            return true;
        }
        else if (id == R.id.satelliteView)
        {
            mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
            return true;
        }
        else if (id == R.id.hybridView)
        {
            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
            return true;
        }
        else if (id == R.id.terrainView)
        {
            mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
            return true;
        }
        else if (id == R.id.noneView)
        {
            mMap.setMapType(GoogleMap.MAP_TYPE_NONE);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
